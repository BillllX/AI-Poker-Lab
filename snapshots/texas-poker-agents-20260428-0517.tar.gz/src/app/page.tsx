"use client";

import { useEffect, useMemo, useState } from "react";
import type { Card, GameSnapshot } from "@/lib/poker/types";

type RegisteredAgent = {
  id: string;
  name: string;
  registeredAt: string;
  lastSeenAt?: string;
};

export default function Home() {
  const [state, setState] = useState<GameSnapshot>();
  const [agents, setAgents] = useState<RegisteredAgent[]>([]);
  const [busyAction, setBusyAction] = useState<string>();
  const [agentId, setAgentId] = useState("");
  const [agentName, setAgentName] = useState("");
  const [error, setError] = useState<string>();

  const sortedPlayers = useMemo(() => state?.players ?? [], [state]);

  async function refresh() {
    const [gameResponse, rosterResponse] = await Promise.all([
      fetch("/api/game/state", { cache: "no-store" }),
      fetch("/api/agents/roster", { cache: "no-store" }),
    ]);
    setState(await gameResponse.json());
    setAgents((await rosterResponse.json()).agents);
  }

  async function command(action: "start" | "stop" | "reset") {
    setBusyAction(action);
    setError(undefined);
    try {
      const response = await fetch(`/api/game/${action}`, {
        method: "POST",
        headers: action === "start" ? { "x-dashboard-action": "start-game" } : undefined,
      });
      const payload = await response.json();
      if (!response.ok) {
        setError(payload.error ?? "操作失败");
        return;
      }
      setState(payload);
    } finally {
      setBusyAction(undefined);
    }
  }

  async function registerExternalAgent(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusyAction("register");
    setError(undefined);

    try {
      const response = await fetch("/api/agents/roster", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id: agentId, name: agentName }),
      });
      const payload = await response.json();

      if (!response.ok) {
        setError(payload.error ?? "Agent 注册失败");
        return;
      }

      setAgents(payload.agents);
      setState(payload.game);
      setAgentId("");
      setAgentName("");
    } finally {
      setBusyAction(undefined);
    }
  }

  async function removeExternalAgent(id: string) {
    setBusyAction(`remove-${id}`);
    setError(undefined);

    try {
      const response = await fetch(`/api/agents/roster?id=${encodeURIComponent(id)}`, { method: "DELETE" });
      const payload = await response.json();

      if (!response.ok) {
        setError(payload.error ?? "Agent 移除失败");
        return;
      }

      setAgents(payload.agents);
      setState(payload.game);
    } finally {
      setBusyAction(undefined);
    }
  }

  useEffect(() => {
    const initial = setTimeout(() => {
      void refresh();
    }, 0);
    const timer = setInterval(() => {
      void refresh();
    }, 1_000);

    return () => {
      clearTimeout(initial);
      clearInterval(timer);
    };
  }, []);

  return (
    <main style={styles.page}>
      <section style={styles.hero}>
        <div>
          <p style={styles.eyebrow}>HTTP Agent Poker Lab</p>
          <h1 style={styles.title}>Agent 互相打德州监控台</h1>
          <p style={styles.subtitle}>
            Agent 不需要公网 IP：先注册入座，然后由 Agent 主动轮询任务并提交动作。
          </p>
          {error && <p style={styles.error}>{error}</p>}
        </div>

        <div style={styles.actions}>
          <button disabled={busyAction === "start" || agents.length < 2} onClick={() => command("start")}>
            开始模拟
          </button>
          <button className="secondary" disabled={busyAction === "stop"} onClick={() => command("stop")}>
            停止会话
          </button>
          <button className="danger" disabled={busyAction === "reset"} onClick={() => command("reset")}>
            重置
          </button>
        </div>
      </section>

      <Panel title="外部 Agent 名册">
        <form style={styles.agentForm} onSubmit={registerExternalAgent}>
          <input
            aria-label="Agent ID"
            onChange={(event) => setAgentId(event.target.value)}
            placeholder="Agent ID，例如 alice-agent"
            required
            style={styles.input}
            value={agentId}
          />
          <input
            aria-label="Agent 名称"
            onChange={(event) => setAgentName(event.target.value)}
            placeholder="Agent 名称，例如 Alice Bot"
            style={styles.input}
            value={agentName}
          />
          <button disabled={busyAction === "register"} type="submit">
            注册入座
          </button>
        </form>

        <p style={styles.helpText}>
          Agent 使用 `GET /api/agents/poll?agentId=...` 拉取待决策任务，再用 `POST /api/agents/action` 提交动作。
          这种模式只要求 Agent 能访问游戏服务。
        </p>

        <div style={styles.roster}>
          {agents.map((agent) => (
            <article key={agent.id} style={styles.rosterItem}>
              <div>
                <strong>{agent.name}</strong>
                <p style={styles.endpoint}>
                  ID: {agent.id} · {agent.lastSeenAt ? `最近轮询 ${new Date(agent.lastSeenAt).toLocaleTimeString()}` : "尚未轮询"}
                </p>
              </div>
              <button
                className="secondary"
                disabled={busyAction === `remove-${agent.id}`}
                onClick={() => removeExternalAgent(agent.id)}
                type="button"
              >
                移除
              </button>
            </article>
          ))}
          {agents.length === 0 && <span style={styles.muted}>还没有外部 Agent 入座。</span>}
        </div>
      </Panel>

      <section style={styles.grid}>
        <Panel title="牌桌">
          <div style={styles.tableStats}>
            <Metric label="手牌编号" value={state?.handId ?? 0} />
            <Metric label="状态" value={state?.running ? "运行中" : "已停止"} />
            <Metric label="阶段" value={state?.phase ?? "-"} />
            <Metric label="底池" value={state?.pot ?? 0} />
            <Metric label="当前注额" value={state?.currentBet ?? 0} />
          </div>

          <div style={styles.cardsRow}>
            {(state?.communityCards.length ? state.communityCards : []).map((card, index) => (
              <PlayingCard key={`${card.rank}${card.suit}${index}`} card={card} />
            ))}
            {!state?.communityCards.length && <span style={styles.muted}>等待发公共牌</span>}
          </div>
        </Panel>

        <Panel title="Agent 筹码">
          <div style={styles.players}>
            {sortedPlayers.map((player) => (
              <article key={player.id} style={styles.playerCard}>
                <div style={styles.playerHeader}>
                  <strong>{player.name}</strong>
                  <span style={styles.badge}>{player.status}</span>
                </div>
                <div style={styles.playerMeta}>
                  <span>筹码 {player.stack}</span>
                  <span>本轮下注 {player.currentBet}</span>
                </div>
                <div style={styles.cardsRowSmall}>
                  {player.holeCards?.map((card, index) => (
                    <PlayingCard key={`${player.id}-${index}`} card={card} />
                  ))}
                </div>
                <p style={styles.lastAction}>最近动作：{player.lastAction ?? "等待"}</p>
                <p style={styles.reasoning}>决策理由：{player.lastReasoning ?? "暂无"}</p>
              </article>
            ))}
          </div>
        </Panel>
      </section>

      <section style={styles.grid}>
        <Panel title="统计">
          <div style={styles.statsList}>
            {state?.stats.map((stat) => {
              const player = state.players.find((item) => item.id === stat.playerId);
              return (
                <div key={stat.playerId} style={styles.statRow}>
                  <span>{player?.name ?? stat.playerId}</span>
                  <span>胜场 {stat.handsWon}</span>
                  <span>手数 {stat.handsPlayed}</span>
                  <span style={{ color: stat.profit >= 0 ? "var(--accent)" : "var(--danger)" }}>
                    盈亏 {stat.profit}
                  </span>
                </div>
              );
            })}
          </div>
        </Panel>

        <Panel title="动作日志">
          <div style={styles.logList}>
            {state?.logs.map((log) => (
              <div key={log.id} style={styles.logItem}>
                <span style={styles.logTime}>{new Date(log.createdAt).toLocaleTimeString()}</span>
                <span>{log.message}</span>
              </div>
            ))}
          </div>
        </Panel>
      </section>
    </main>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section style={styles.panel}>
      <h2 style={styles.panelTitle}>{title}</h2>
      {children}
    </section>
  );
}

function Metric({ label, value }: { label: string; value: string | number }) {
  return (
    <div style={styles.metric}>
      <span style={styles.muted}>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function PlayingCard({ card }: { card: Card }) {
  const red = card.suit === "h" || card.suit === "d";
  const suit = { s: "♠", h: "♥", d: "♦", c: "♣" }[card.suit];

  return <span className={`card ${red ? "red" : ""}`}>{`${card.rank}${suit}`}</span>;
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    display: "flex",
    flexDirection: "column",
    gap: "1rem",
    margin: "0 auto",
    maxWidth: "1180px",
    padding: "2rem",
  },
  hero: {
    alignItems: "center",
    display: "flex",
    gap: "1rem",
    justifyContent: "space-between",
  },
  eyebrow: {
    color: "var(--accent)",
    fontSize: "0.8rem",
    fontWeight: 800,
    letterSpacing: "0.12em",
    margin: 0,
    textTransform: "uppercase",
  },
  title: {
    fontSize: "clamp(2rem, 5vw, 4rem)",
    lineHeight: 1,
    margin: "0.5rem 0",
  },
  subtitle: {
    color: "var(--muted)",
    margin: 0,
    maxWidth: "42rem",
  },
  error: {
    background: "rgba(251, 113, 133, 0.14)",
    border: "1px solid rgba(251, 113, 133, 0.35)",
    borderRadius: "0.8rem",
    color: "var(--danger)",
    margin: "1rem 0 0",
    padding: "0.75rem",
  },
  actions: {
    display: "flex",
    flexWrap: "wrap",
    gap: "0.75rem",
    justifyContent: "flex-end",
  },
  grid: {
    display: "grid",
    gap: "1rem",
    gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
  },
  panel: {
    background: "linear-gradient(180deg, var(--panel-strong), var(--panel))",
    border: "1px solid var(--border)",
    borderRadius: "1.25rem",
    boxShadow: "0 20px 60px rgba(0, 0, 0, 0.22)",
    padding: "1.25rem",
  },
  panelTitle: {
    margin: "0 0 1rem",
  },
  agentForm: {
    display: "grid",
    gap: "0.75rem",
    gridTemplateColumns: "minmax(160px, 0.9fr) minmax(160px, 0.9fr) auto",
  },
  input: {
    background: "rgba(255, 255, 255, 0.08)",
    border: "1px solid var(--border)",
    borderRadius: "999px",
    color: "var(--text)",
    font: "inherit",
    minWidth: 0,
    padding: "0.75rem 1rem",
  },
  helpText: {
    color: "var(--muted)",
    fontSize: "0.9rem",
    margin: "0.8rem 0 1rem",
  },
  roster: {
    display: "grid",
    gap: "0.75rem",
  },
  rosterItem: {
    alignItems: "center",
    background: "rgba(255, 255, 255, 0.05)",
    border: "1px solid var(--border)",
    borderRadius: "1rem",
    display: "flex",
    gap: "1rem",
    justifyContent: "space-between",
    padding: "0.9rem 1rem",
  },
  endpoint: {
    color: "var(--muted)",
    margin: "0.25rem 0 0",
    overflowWrap: "anywhere",
  },
  tableStats: {
    display: "grid",
    gap: "0.75rem",
    gridTemplateColumns: "repeat(auto-fit, minmax(110px, 1fr))",
    marginBottom: "1.5rem",
  },
  metric: {
    background: "rgba(255, 255, 255, 0.05)",
    borderRadius: "0.9rem",
    display: "flex",
    flexDirection: "column",
    gap: "0.25rem",
    padding: "0.9rem",
  },
  muted: {
    color: "var(--muted)",
  },
  cardsRow: {
    alignItems: "center",
    display: "flex",
    flexWrap: "wrap",
    gap: "0.7rem",
    minHeight: "3rem",
  },
  cardsRowSmall: {
    display: "flex",
    gap: "0.5rem",
    marginTop: "0.85rem",
  },
  players: {
    display: "grid",
    gap: "0.85rem",
  },
  playerCard: {
    background: "rgba(255, 255, 255, 0.05)",
    border: "1px solid var(--border)",
    borderRadius: "1rem",
    padding: "1rem",
  },
  playerHeader: {
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between",
  },
  badge: {
    background: "rgba(110, 231, 168, 0.14)",
    borderRadius: "999px",
    color: "var(--accent)",
    fontSize: "0.78rem",
    padding: "0.2rem 0.55rem",
  },
  playerMeta: {
    color: "var(--muted)",
    display: "flex",
    fontSize: "0.9rem",
    gap: "1rem",
    marginTop: "0.5rem",
  },
  lastAction: {
    color: "var(--muted)",
    margin: "0.75rem 0 0",
  },
  reasoning: {
    color: "var(--muted)",
    fontSize: "0.88rem",
    lineHeight: 1.45,
    margin: "0.35rem 0 0",
  },
  statsList: {
    display: "grid",
    gap: "0.65rem",
  },
  statRow: {
    alignItems: "center",
    background: "rgba(255, 255, 255, 0.05)",
    borderRadius: "0.8rem",
    display: "grid",
    gap: "0.5rem",
    gridTemplateColumns: "1.2fr repeat(3, 0.8fr)",
    padding: "0.75rem",
  },
  logList: {
    display: "flex",
    flexDirection: "column",
    gap: "0.55rem",
    maxHeight: "26rem",
    overflow: "auto",
  },
  logItem: {
    borderBottom: "1px solid var(--border)",
    display: "grid",
    gap: "0.75rem",
    gridTemplateColumns: "5.5rem 1fr",
    paddingBottom: "0.55rem",
  },
  logTime: {
    color: "var(--muted)",
    fontVariantNumeric: "tabular-nums",
  },
};
