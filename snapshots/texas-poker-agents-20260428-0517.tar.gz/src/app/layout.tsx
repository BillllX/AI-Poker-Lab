import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Texas Poker Agents",
  description: "HTTP API based Texas Hold'em agent simulator",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
