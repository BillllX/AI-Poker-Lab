import { listAgents, normalizeAgentId, registerAgent, removeAgent } from "@/lib/server/agentRegistry";
import { listPendingDecisions } from "@/lib/server/decisionBroker";
import { getSimulator } from "@/lib/server/simulator";

export async function GET() {
  return Response.json({ agents: listAgents(), pendingDecisions: listPendingDecisions() });
}

export async function POST(request: Request) {
  try {
    const origin = new URL(request.url).origin;
    const simulator = getSimulator(origin);
    const input = await request.json();
    const agentId = normalizeAgentId(input.id || input.name || "");
    const existingAgent = listAgents().find((agent) => agent.id === agentId);

    if (simulator.isRunning() && !existingAgent) {
      return Response.json({ error: "Cannot add a new Agent while the game is running. Stop or reset the game first." }, { status: 409 });
    }

    if (simulator.isRunning() && existingAgent && input.name && input.name.trim() !== existingAgent.name) {
      return Response.json({ error: "Cannot rename an Agent while the game is running. Stop or reset the game first." }, { status: 409 });
    }

    const agent = registerAgent(input);

    if (!existingAgent) {
      simulator.reset(origin);
    }

    return Response.json({ agent, agents: listAgents(), game: simulator.snapshot() });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Invalid Agent registration." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  const origin = new URL(request.url).origin;
  const id = new URL(request.url).searchParams.get("id");

  if (!id) {
    return Response.json({ error: "Agent id is required." }, { status: 400 });
  }

  const simulator = getSimulator(origin);

  if (simulator.isRunning()) {
    return Response.json({ error: "Cannot remove an Agent while the game is running. Stop or reset the game first." }, { status: 409 });
  }

  const removed = removeAgent(id);
  simulator.reset(origin);

  return Response.json({ removed, agents: listAgents(), game: simulator.snapshot() });
}
