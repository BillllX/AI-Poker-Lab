import { decideForAgent } from "@/lib/agents/strategies";
import type { AgentDecisionRequest } from "@/lib/poker/types";

export async function POST(request: Request, context: { params: Promise<{ agentId: string }> }) {
  const { agentId } = await context.params;
  const body = (await request.json()) as AgentDecisionRequest;

  return Response.json(decideForAgent(agentId, body));
}
