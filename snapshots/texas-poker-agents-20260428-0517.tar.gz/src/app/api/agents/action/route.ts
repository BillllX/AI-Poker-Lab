import { submitDecision } from "@/lib/server/decisionBroker";
import type { AgentDecisionResponse } from "@/lib/poker/types";

export async function POST(request: Request) {
  try {
    submitDecision((await request.json()) as AgentDecisionResponse & { requestId?: string });
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Invalid decision response." }, { status: 400 });
  }
}
