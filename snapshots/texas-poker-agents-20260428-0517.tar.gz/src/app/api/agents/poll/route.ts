import { listAgents, markAgentSeen } from "@/lib/server/agentRegistry";
import { getPendingDecision } from "@/lib/server/decisionBroker";

export async function GET(request: Request) {
  const agentId = new URL(request.url).searchParams.get("agentId");

  if (!agentId) {
    return Response.json({ error: "agentId is required." }, { status: 400 });
  }

  const agent = listAgents().find((item) => item.id === agentId);
  if (!agent) {
    return Response.json(
      {
        agentId,
        task: null,
        shouldStop: true,
        reason: "Agent is not registered. The game session may have been stopped; register again before polling.",
      },
      { status: 410 },
    );
  }

  markAgentSeen(agentId);

  return Response.json({
    agentId,
    shouldStop: false,
    task: getPendingDecision(agentId) ?? null,
  });
}
