import { getSimulator } from "@/lib/server/simulator";

export async function POST(request: Request) {
  const origin = new URL(request.url).origin;
  const simulator = getSimulator(origin);
  simulator.endSession(origin);

  return Response.json(simulator.snapshot());
}
