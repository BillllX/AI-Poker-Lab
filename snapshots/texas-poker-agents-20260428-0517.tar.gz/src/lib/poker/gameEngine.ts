import { createDeck, formatCard, shuffle } from "./cards";
import { compareHands, evaluateTexasHand } from "./handEvaluator";
import type {
  ActionLog,
  AgentDecisionRequest,
  AgentDecisionResponse,
  AgentStats,
  BettingRound,
  Card,
  GameSnapshot,
  LegalAction,
  PlayerState,
  PokerAction,
} from "./types";

type PlayerConfig = {
  id: string;
  name: string;
  endpoint?: string;
};

type RequestAction = (request: AgentDecisionRequest) => Promise<AgentDecisionResponse>;
type PlayerDecision = {
  action: PokerAction;
  reasoning?: string;
};

const initialStack = 1_000;

export class PokerGameEngine {
  private deck: Card[] = [];
  private players: PlayerState[];
  private communityCards: Card[] = [];
  private logs: ActionLog[] = [];
  private stats: AgentStats[];
  private handId = 0;
  private dealerIndex = -1;
  private pot = 0;
  private phase: BettingRound = "preflop";
  private currentBet = 0;
  private running = false;

  readonly smallBlind = 5;
  readonly bigBlind = 10;

  constructor(players: PlayerConfig[]) {
    this.players = players.map((player) => ({
      ...player,
      stack: initialStack,
      holeCards: [],
      currentBet: 0,
      totalCommitted: 0,
      status: "active",
      lastReasoning: undefined,
    }));
    this.stats = players.map((player) => ({
      playerId: player.id,
      handsWon: 0,
      handsPlayed: 0,
      profit: 0,
    }));
  }

  setRunning(running: boolean) {
    this.running = running;
  }

  isRunning() {
    return this.running;
  }

  reset() {
    this.deck = [];
    this.communityCards = [];
    this.logs = [];
    this.handId = 0;
    this.dealerIndex = -1;
    this.pot = 0;
    this.phase = "preflop";
    this.currentBet = 0;
    this.running = false;
    this.players = this.players.map((player) => ({
      ...player,
      stack: initialStack,
      holeCards: [],
      currentBet: 0,
      totalCommitted: 0,
      status: "active",
      lastAction: undefined,
      lastReasoning: undefined,
    }));
    this.stats = this.stats.map((stat) => ({
      ...stat,
      handsWon: 0,
      handsPlayed: 0,
      profit: 0,
    }));
  }

  async playOneHand(requestAction: RequestAction) {
    this.prepareHand();
    await this.bettingRound("preflop", this.nextSeat(this.bigBlindIndex()), requestAction);

    if (this.activePlayers().length > 1) {
      this.dealCommunity(3);
      await this.bettingRound("flop", this.nextSeat(this.dealerIndex), requestAction);
    }

    if (this.activePlayers().length > 1) {
      this.dealCommunity(1);
      await this.bettingRound("turn", this.nextSeat(this.dealerIndex), requestAction);
    }

    if (this.activePlayers().length > 1) {
      this.dealCommunity(1);
      await this.bettingRound("river", this.nextSeat(this.dealerIndex), requestAction);
    }

    this.phase = "showdown";
    this.awardPot();
  }

  snapshot(): GameSnapshot {
    return {
      handId: this.handId,
      running: this.running,
      phase: this.phase,
      dealerIndex: this.dealerIndex,
      smallBlind: this.smallBlind,
      bigBlind: this.bigBlind,
      pot: this.pot,
      currentBet: this.currentBet,
      minRaise: this.bigBlind,
      communityCards: this.communityCards,
      players: this.players.map((player) => ({ ...player })),
      logs: this.logs.slice(-80).reverse(),
      stats: this.stats,
    };
  }

  private prepareHand() {
    if (this.players.filter((player) => player.stack > 0).length < 2) {
      this.players = this.players.map((player) => ({ ...player, stack: initialStack, status: "active" }));
      this.log("system", "筹码不足两人的情况出现，所有 Agent 重新买入。");
    }

    this.handId += 1;
    this.dealerIndex = this.nextSeat(this.dealerIndex);
    this.deck = shuffle(createDeck());
    this.communityCards = [];
    this.pot = 0;
    this.currentBet = this.bigBlind;
    this.phase = "preflop";

    this.players = this.players.map((player) => ({
      ...player,
      holeCards: player.stack > 0 ? [this.draw(), this.draw()] : [],
      currentBet: 0,
      totalCommitted: 0,
      status: player.stack > 0 ? "active" : "out",
      lastAction: undefined,
      lastReasoning: undefined,
    }));

    for (const stat of this.stats) {
      stat.handsPlayed += 1;
    }

    this.postBlind(this.smallBlindIndex(), this.smallBlind, "小盲");
    this.postBlind(this.bigBlindIndex(), this.bigBlind, "大盲");
    this.log("system", `第 ${this.handId} 手牌开始。`);
  }

  private async bettingRound(round: BettingRound, startIndex: number, requestAction: RequestAction) {
    this.phase = round;

    if (round !== "preflop") {
      this.currentBet = 0;
      this.players = this.players.map((player) => ({ ...player, currentBet: 0 }));
    }

    const pending = new Set(this.actionablePlayers().map((player) => player.id));
    let seat = startIndex;
    let guard = 0;

    while (pending.size > 0 && this.activePlayers().length > 1 && guard < 100) {
      guard += 1;
      const player = this.players[seat];
      seat = this.nextSeat(seat);

      if (!player || !pending.has(player.id) || player.status !== "active" || player.stack <= 0) {
        continue;
      }

      const decision = await this.requestPlayerAction(player, pending, requestAction);
      const raised = this.applyAction(player.id, decision);
      pending.delete(player.id);

      if (raised) {
        for (const opponent of this.actionablePlayers()) {
          if (opponent.id !== player.id) {
            pending.add(opponent.id);
          }
        }
      }
    }
  }

  private async requestPlayerAction(player: PlayerState, pending: Set<string>, requestAction: RequestAction) {
    const toCall = Math.max(0, this.currentBet - player.currentBet);
    const legalActions = this.legalActionsFor(player);
    const publicState = this.snapshot() as Partial<GameSnapshot>;
    delete publicState.logs;
    const request: AgentDecisionRequest = {
      type: "decision_request",
      handId: this.handId,
      playerId: player.id,
      privateCards: player.holeCards,
      publicState: {
        ...(publicState as Omit<GameSnapshot, "logs">),
        players: this.players.map((visiblePlayer) => ({
          ...visiblePlayer,
          holeCards: visiblePlayer.id === player.id ? visiblePlayer.holeCards : undefined,
        })),
        currentPlayerId: player.id,
      },
      legalActions,
      toCall,
      minRaise: this.bigBlind,
      stack: player.stack,
    };

    try {
      const decision = await requestAction(request);
      return {
        action: normalizeAction(decision.action, legalActions, toCall),
        reasoning: decision.reasoning,
      };
    } catch (error) {
      pending.delete(player.id);
      this.log(player.id, `Agent 决策失败或超时，自动执行保守动作：${String(error)}`);
      return { action: fallbackAction(toCall), reasoning: "Agent 决策失败或超时，服务端执行保守兜底动作。" };
    }
  }

  private legalActionsFor(player: PlayerState): LegalAction[] {
    const toCall = Math.max(0, this.currentBet - player.currentBet);

    if (toCall > 0) {
      return player.stack > toCall ? ["fold", "call", "raise"] : ["fold", "call"];
    }

    return player.stack > this.bigBlind ? ["check", "bet"] : ["check"];
  }

  private applyAction(playerId: string, decision: PlayerDecision): boolean {
    const action = decision.action;
    const reasoning = sanitizeReasoning(decision.reasoning);
    const index = this.players.findIndex((player) => player.id === playerId);
    const player = this.players[index];
    const beforeBet = this.currentBet;
    const toCall = Math.max(0, this.currentBet - player.currentBet);

    if (action.type === "fold") {
      this.players[index] = { ...player, status: "folded", lastAction: "fold", lastReasoning: reasoning };
      this.log(player.id, withReasoning(`${player.name} 弃牌。`, reasoning));
      return false;
    }

    if (action.type === "check" && toCall === 0) {
      this.players[index] = { ...player, lastAction: "check", lastReasoning: reasoning };
      this.log(player.id, withReasoning(`${player.name} 过牌。`, reasoning));
      return false;
    }

    if (action.type === "call" || (action.type === "check" && toCall > 0)) {
      this.commitChips(index, toCall);
      this.players[index] = { ...this.players[index], lastReasoning: reasoning };
      this.log(player.id, withReasoning(`${player.name} 跟注 ${Math.min(toCall, player.stack)}。`, reasoning));
      return false;
    }

    const targetBet = this.targetBetFor(action);
    this.commitChips(index, Math.max(0, targetBet - player.currentBet));
    const updated = this.players[index];
    this.currentBet = Math.max(this.currentBet, updated.currentBet);
    this.players[index] = { ...updated, lastReasoning: reasoning };
    this.log(player.id, withReasoning(`${player.name} ${beforeBet === 0 ? "下注" : "加注到"} ${updated.currentBet}。`, reasoning));

    return this.currentBet > beforeBet;
  }

  private targetBetFor(action: PokerAction) {
    if (action.type === "bet") {
      return Math.max(this.bigBlind, safeAmount(action.amount, this.bigBlind));
    }

    if (action.type === "raise") {
      return Math.max(this.currentBet + this.bigBlind, safeAmount(action.amount, this.currentBet + this.bigBlind));
    }

    return this.currentBet;
  }

  private commitChips(index: number, requestedAmount: number) {
    const player = this.players[index];
    const amount = Number.isFinite(requestedAmount) ? Math.max(0, Math.min(requestedAmount, player.stack)) : 0;
    const nextStack = player.stack - amount;

    this.players[index] = {
      ...player,
      stack: nextStack,
      currentBet: player.currentBet + amount,
      totalCommitted: player.totalCommitted + amount,
      status: nextStack === 0 ? "all-in" : player.status,
      lastAction: amount >= requestedAmount ? "commit" : "all-in",
    };
    this.pot += amount;
  }

  private awardPot() {
    const contenders = this.activePlayers();
    const handWinners = new Set<string>();

    if (contenders.length === 1) {
      const wonAmount = this.pot;
      this.payWinner(contenders[0].id, wonAmount);
      handWinners.add(contenders[0].id);
      this.log(contenders[0].id, `${contenders[0].name} 赢得底池 ${wonAmount}。`);
      this.recordHandWins(handWinners);
      this.updateProfitStats();
      this.pot = 0;
      return;
    }

    const evaluated = contenders.map((player) => ({
      player,
      hand: evaluateTexasHand([...player.holeCards, ...this.communityCards]),
    }));

    for (const pot of buildPots(this.players)) {
      const eligible = evaluated.filter((entry) => pot.eligiblePlayerIds.includes(entry.player.id));
      const best = eligible.sort((left, right) => compareHands(left.hand, right.hand)).at(-1);

      if (!best) {
        continue;
      }

      const winners = eligible.filter((entry) => compareHands(entry.hand, best.hand) === 0);
      const share = Math.floor(pot.amount / winners.length);
      let remainder = pot.amount % winners.length;

      for (const winner of winners) {
        const wonAmount = share + (remainder > 0 ? 1 : 0);
        remainder = Math.max(0, remainder - 1);
        this.payWinner(winner.player.id, wonAmount);
        handWinners.add(winner.player.id);
        this.log(
          winner.player.id,
          `${winner.player.name} 以 ${winner.hand.rank} 赢得${pot.label} ${wonAmount}，手牌 ${winner.player.holeCards.map(formatCard).join(" ")}。`,
        );
      }
    }

    this.recordHandWins(handWinners);
    this.updateProfitStats();
    this.pot = 0;
  }

  private payWinner(playerId: string, amount: number) {
    const index = this.players.findIndex((player) => player.id === playerId);
    this.players[index] = {
      ...this.players[index],
      stack: this.players[index].stack + amount,
    };
  }

  private recordHandWins(winnerIds: Set<string>) {
    for (const winnerId of winnerIds) {
      const stat = this.stats.find((item) => item.playerId === winnerId);
      if (stat) {
        stat.handsWon += 1;
      }
    }
  }

  private updateProfitStats() {
    for (const player of this.players) {
      const playerStat = this.stats.find((item) => item.playerId === player.id);
      if (playerStat) {
        playerStat.profit = player.stack - initialStack;
      }
    }
  }

  private postBlind(index: number, amount: number, label: string) {
    const player = this.players[index];
    this.commitChips(index, amount);
    this.log(player.id, `${player.name} 支付${label} ${amount}。`);
  }

  private dealCommunity(count: number) {
    this.communityCards.push(...Array.from({ length: count }, () => this.draw()));
    this.log("dealer", `公共牌：${this.communityCards.map(formatCard).join(" ")}。`);
  }

  private draw() {
    const card = this.deck.pop();
    if (!card) {
      throw new Error("Deck is empty.");
    }
    return card;
  }

  private smallBlindIndex() {
    return this.nextSeat(this.dealerIndex);
  }

  private bigBlindIndex() {
    return this.nextSeat(this.smallBlindIndex());
  }

  private nextSeat(index: number) {
    if (this.players.length === 0) {
      return 0;
    }

    for (let offset = 1; offset <= this.players.length; offset += 1) {
      const next = (index + offset + this.players.length) % this.players.length;
      if (this.players[next].stack > 0 || this.players[next].status !== "out") {
        return next;
      }
    }

    return 0;
  }

  private activePlayers() {
    return this.players.filter((player) => player.status === "active" || player.status === "all-in");
  }

  private actionablePlayers() {
    return this.players.filter((player) => player.status === "active" && player.stack > 0);
  }

  private log(actor: string, message: string) {
    this.logs.push({
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      handId: this.handId,
      actor,
      message,
      createdAt: new Date().toISOString(),
    });
  }
}

function fallbackAction(toCall: number): PokerAction {
  return toCall > 0 ? { type: "fold" } : { type: "check" };
}

function normalizeAction(action: PokerAction | undefined, legalActions: LegalAction[], toCall: number): PokerAction {
  if (!action || !legalActions.includes(action.type)) {
    return fallbackAction(toCall);
  }

  if (action.type === "bet" || action.type === "raise") {
    const amount = Number(action.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      return fallbackAction(toCall);
    }

    return { type: action.type, amount };
  }

  return { type: action.type };
}

function safeAmount(amount: number, fallback: number) {
  const parsed = Number(amount);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function sanitizeReasoning(reasoning?: string) {
  const trimmed = reasoning?.trim();
  return trimmed ? trimmed.slice(0, 500) : undefined;
}

function withReasoning(message: string, reasoning?: string) {
  return reasoning ? `${message} 理由：${reasoning}` : message;
}

function buildPots(players: PlayerState[]) {
  const levels = [...new Set(players.map((player) => player.totalCommitted).filter((amount) => amount > 0))].sort(
    (left, right) => left - right,
  );
  const pots: Array<{ amount: number; eligiblePlayerIds: string[]; label: string }> = [];
  let previousLevel = 0;

  for (const level of levels) {
    const contributors = players.filter((player) => player.totalCommitted >= level);
    const amount = (level - previousLevel) * contributors.length;
    const eligiblePlayerIds = contributors
      .filter((player) => player.status === "active" || player.status === "all-in")
      .map((player) => player.id);

    if (amount > 0 && eligiblePlayerIds.length > 0) {
      pots.push({
        amount,
        eligiblePlayerIds,
        label: pots.length === 0 ? "主池" : `边池 ${pots.length}`,
      });
    }

    previousLevel = level;
  }

  return pots;
}
