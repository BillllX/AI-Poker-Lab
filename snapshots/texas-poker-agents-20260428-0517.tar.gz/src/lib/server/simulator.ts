import { PokerGameEngine } from "../poker/gameEngine";
import type { GameSnapshot } from "../poker/types";
import { clearAgents, listAgents } from "./agentRegistry";
import { clearPendingDecisions, enqueueDecision } from "./decisionBroker";

class GameSimulator {
  private engine: PokerGameEngine;
  private timer?: ReturnType<typeof setInterval>;
  private inFlight = false;
  private origin: string;
  private rosterVersion = "";

  constructor(origin: string) {
    this.origin = origin;
    this.engine = this.createEngine();
  }

  configure(origin: string) {
    if (origin === this.origin && this.rosterVersion === this.currentRosterVersion()) {
      return;
    }

    const wasRunning = this.engine.isRunning();
    this.stop();
    this.origin = origin;
    this.engine = this.createEngine();

    if (wasRunning) {
      this.start();
    }
  }

  start() {
    if (listAgents().length < 2) {
      throw new Error("At least two external Agents are required to start a game.");
    }

    if (!this.engine.isRunning()) {
      clearPendingDecisions("Game is starting a new run.");
      this.inFlight = false;
    }

    this.engine.setRunning(true);

    if (!this.timer) {
      this.timer = setInterval(() => {
        void this.tick();
      }, 1_200);
    }

    void this.tick();
  }

  isRunning() {
    return this.engine.isRunning();
  }

  stop() {
    this.engine.setRunning(false);
    clearPendingDecisions("Game was stopped or reconfigured.");
    this.inFlight = false;

    if (this.timer) {
      clearInterval(this.timer);
      this.timer = undefined;
    }
  }

  reset(origin: string) {
    this.stop();
    this.origin = origin;
    this.engine = this.createEngine();
    this.engine.reset();
  }

  endSession(origin: string) {
    this.stop();
    clearAgents();
    this.origin = origin;
    this.engine = this.createEngine();
    this.engine.reset();
  }

  snapshot(): GameSnapshot {
    this.configure(this.origin);
    return this.engine.snapshot();
  }

  private async tick() {
    if (!this.engine.isRunning() || this.inFlight) {
      return;
    }

    this.inFlight = true;
    try {
      await this.engine.playOneHand(enqueueDecision);
    } finally {
      this.inFlight = false;
    }
  }

  private createEngine() {
    const agents = listAgents();
    this.rosterVersion = this.currentRosterVersion();

    return new PokerGameEngine(agents);
  }

  private currentRosterVersion() {
    return JSON.stringify(listAgents().map((agent) => [agent.id, agent.name]));
  }
}

let simulator: GameSimulator | undefined;

export function getSimulator(origin = "http://localhost:3000") {
  if (!simulator) {
    simulator = new GameSimulator(origin);
  } else {
    simulator.configure(origin);
  }

  return simulator;
}
