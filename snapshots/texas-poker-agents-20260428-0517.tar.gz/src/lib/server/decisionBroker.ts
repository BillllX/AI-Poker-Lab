import type { AgentDecisionRequest, AgentDecisionResponse } from "../poker/types";

type PendingDecision = {
  request: AgentDecisionRequest & { requestId: string };
  createdAt: string;
  expiresAt: string;
  resolve: (response: AgentDecisionResponse) => void;
  reject: (error: Error) => void;
  timer: ReturnType<typeof setTimeout>;
};

const pending = new Map<string, PendingDecision>();
const timeoutMs = 120_000;

export function enqueueDecision(request: AgentDecisionRequest) {
  const requestId = `${request.handId}-${request.playerId}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const createdAt = new Date();
  const expiresAt = new Date(createdAt.getTime() + timeoutMs);

  return new Promise<AgentDecisionResponse>((resolve, reject) => {
    const timer = setTimeout(() => {
      pending.delete(requestId);
      reject(new Error(`Agent ${request.playerId} did not submit an action before timeout.`));
    }, timeoutMs);

    pending.set(requestId, {
      request: { ...request, requestId },
      createdAt: createdAt.toISOString(),
      expiresAt: expiresAt.toISOString(),
      resolve,
      reject,
      timer,
    });
  });
}

export function getPendingDecision(agentId: string) {
  const now = Date.now();
  const decision = [...pending.values()]
    .filter((item) => item.request.playerId === agentId && new Date(item.expiresAt).getTime() > now)
    .sort((left, right) => new Date(left.createdAt).getTime() - new Date(right.createdAt).getTime())
    .at(0);

  if (!decision) {
    return undefined;
  }

  return {
    request: decision.request,
    createdAt: decision.createdAt,
    expiresAt: decision.expiresAt,
  };
}

export function submitDecision(response: AgentDecisionResponse & { requestId?: string }) {
  if (!response.requestId) {
    throw new Error("requestId is required.");
  }

  const decision = pending.get(response.requestId);
  if (!decision) {
    throw new Error("Decision request was not found or has expired.");
  }

  if (decision.request.playerId !== response.playerId) {
    throw new Error("Decision response playerId does not match the pending request.");
  }

  clearTimeout(decision.timer);
  pending.delete(response.requestId);
  decision.resolve(response);
}

export function listPendingDecisions() {
  return [...pending.values()].map((decision) => ({
    requestId: decision.request.requestId,
    playerId: decision.request.playerId,
    handId: decision.request.handId,
    createdAt: decision.createdAt,
    expiresAt: decision.expiresAt,
  }));
}

export function clearPendingDecisions(reason = "Decision queue was cleared.") {
  for (const [requestId, decision] of pending) {
    clearTimeout(decision.timer);
    decision.reject(new Error(reason));
    pending.delete(requestId);
  }
}
