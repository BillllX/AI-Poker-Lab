export type RegisteredAgent = {
  id: string;
  name: string;
  registeredAt: string;
  lastSeenAt?: string;
};

export type AgentRegistrationInput = {
  id?: string;
  name?: string;
};

let agents = loadAgentsFromEnv();

export function listAgents() {
  return agents;
}

export function registerAgent(input: AgentRegistrationInput) {
  const id = normalizeAgentId(input.id || input.name || "");
  const name = normalizeName(input.name || id);
  const agent: RegisteredAgent = {
    id,
    name,
    registeredAt: new Date().toISOString(),
    lastSeenAt: agents.find((item) => item.id === id)?.lastSeenAt,
  };

  agents = [...agents.filter((item) => item.id !== id), agent];
  return agent;
}

export function removeAgent(id: string) {
  const before = agents.length;
  agents = agents.filter((agent) => agent.id !== id);
  return agents.length !== before;
}

export function markAgentSeen(id: string) {
  const now = new Date().toISOString();
  agents = agents.map((agent) => (agent.id === id ? { ...agent, lastSeenAt: now } : agent));
  return agents.find((agent) => agent.id === id);
}

export function clearAgents() {
  agents = [];
}

function loadAgentsFromEnv() {
  const raw = process.env.EXTERNAL_AGENTS_JSON;
  if (!raw) {
    return [];
  }

  try {
    const parsed = JSON.parse(raw) as AgentRegistrationInput[];
    return parsed.map(registerAgentFromEnv);
  } catch {
    return [];
  }
}

function registerAgentFromEnv(input: AgentRegistrationInput): RegisteredAgent {
  const id = normalizeAgentId(input.id || input.name || "");
  const name = normalizeName(input.name || id);

  return {
    id,
    name,
    registeredAt: new Date().toISOString(),
  };
}

export function normalizeAgentId(value: string) {
  const id = value
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 48);

  if (!id) {
    throw new Error("Agent id must contain letters or numbers.");
  }

  return id;
}

function normalizeName(value: string) {
  return value.trim().slice(0, 64) || "External Agent";
}
