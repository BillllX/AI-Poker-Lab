---
name: texas-poker-agent
description: Build or connect external Texas Hold'em poker agents for this project. Use when implementing an agent decision service, integrating an LLM/player bot, testing HTTP poker participation, or explaining how agents join the game.
---

# Texas Poker Agent

## Purpose

This project runs a Texas Hold'em simulator where external Agents participate by polling the game service for decisions. Participating Agents are expected to use their own large language model to decide poker actions.

Use this skill when you need to create, debug, or connect an external Agent that participates in the game.

## Architecture

The communication pattern is pull-based:

```text
Agent -> register with Game Service
Agent -> poll Game Service for pending decision tasks
Agent -> submit selected action back to Game Service
Dashboard -> HTTP polling -> Game State API
```

Agents do not mutate game state directly. They only receive a decision request and return one legal poker action.

Agents do not need a public IP. They only need outbound network access to the game service.

## Decision Requirement

Each Agent should use its own large language model for poker decisions.

The Agent program should handle protocol work only: registering, polling, formatting the game state for the model, validating the model output, and submitting the final action.

Do not replace the model with a hard-coded poker strategy such as "always call", "always check", or fixed hand-strength rules. Program logic must not choose strategic poker actions.

Strict requirement: for every `task.request` that requires an action, the Agent must make a fresh LLM call using that exact request before submitting `/api/agents/action`.

Do not submit actions from cached decisions, precomputed policies, lookup tables, scripted strategies, random choice, static heuristics, or previous-hand reasoning.

If the LLM call fails, produces invalid JSON, violates `legalActions`, hallucinates impossible facts, or the task is close to expiration before a valid model decision is available, the Agent must fold immediately. This is not a strategic fallback; it is a failure policy. If `fold` is somehow not legal, use `check` only because it is the only non-betting safe action. The Chinese `reasoning` must explicitly say the model failed and the Agent is folding.

## Run The Local Game Server

Start the app:

```bash
npm run dev -- --hostname 127.0.0.1
```

Useful APIs:

```text
GET  http://127.0.0.1:3000/api/agents/skill
GET  http://127.0.0.1:3000/api/agents/roster
POST http://127.0.0.1:3000/api/agents/roster
DELETE http://127.0.0.1:3000/api/agents/roster?id=<agent-id>
GET  http://127.0.0.1:3000/api/agents/poll?agentId=<agent-id>
POST http://127.0.0.1:3000/api/agents/action
GET  http://127.0.0.1:3000/api/game/state
```

Agents must not call game control endpoints such as start, stop, or reset. The game starts only when a human operator clicks Start in the monitoring dashboard.

## Register To Join A Game

Register an Agent ID with the game service:

```bash
curl -s -X POST https://your-game.example.com/api/agents/roster \
  -H 'content-type: application/json' \
  -d '{
    "id": "alice-agent",
    "name": "Alice Agent"
  }'
```

The game requires at least two registered external Agents before the dashboard operator can start it.

## Runtime Pattern

After registration, keep a dedicated polling worker alive for this Agent. Do not rely on manual one-off polling from the main conversation.

The worker's only job is:

1. Poll `/api/agents/poll?agentId=<agent-id>`.
2. If the response has `shouldStop: true`, stop the worker immediately.
3. If `task` is `null`, sleep briefly and poll again.
4. If `task.request` exists, call the Agent's own large language model for this exact task before deciding.
5. Validate the model output against `legalActions`.
6. Submit the final action and model reasoning to `/api/agents/action`.
7. Continue polling until the game service returns `shouldStop: true` or the user explicitly stops the Agent.

Recommended host-specific patterns:

- Cursor: launch a background subagent or long-running worker process dedicated to polling, model calls, validation, and action submission. Keep the main chat free for user interaction and debugging.
- OpenClaw: launch a watchdog/background worker for the Agent. The watchdog should keep polling even if the main interaction thread is idle, and should restart or report errors if the polling loop fails. When calling the LLM from OpenClaw, set a sufficiently large output token budget, for example `max_tokens`/`max_output_tokens` of at least 800, so the JSON response and reasoning are not truncated.
- Generic Node/Python runtime: run an independent daemon, process, async loop, or scheduled worker. The implementation can vary, but the Agent must continuously poll while participating.

The worker should be resilient: catch network/model errors, back off briefly, and never submit actions without the matching `requestId`. If a valid LLM decision is unavailable for a task, submit `fold` with Chinese reasoning that identifies the model failure.

When the game host stops a session, registered Agents are removed from the roster. Polling then returns HTTP `410` with `shouldStop: true`. The worker must exit and must not keep polling. To play again, the Agent must be explicitly re-triggered, register again through `/api/agents/roster`, and start a new watchdog worker.

## LLM Output Contract

All LLMs must return exactly one JSON object and nothing else. Do not return Markdown, code fences, prose before/after the JSON, comments, or multiple candidate actions.

Required schema:

```json
{
  "action": {
    "type": "fold"
  },
  "reasoning": "用中文简要说明决策依据，必须基于当前手牌、公共牌、底池、筹码、toCall 和 legalActions。"
}
```

For `bet` and `raise`, include a positive numeric `amount`:

```json
{
  "action": {
    "type": "raise",
    "amount": 80
  },
  "reasoning": "我有较强成牌，可能被更差牌跟注，因此加注到 80 争取价值。"
}
```

Valid `action.type` values are exactly `fold`, `check`, `call`, `bet`, and `raise`.

The watchdog must parse this JSON, validate `action.type` against `legalActions`, validate `amount` for `bet`/`raise`, and then submit the parsed action plus `reasoning` to `/api/agents/action`.

`reasoning` must be written in Chinese. Do not submit English reasoning to the game service.

Configure the model call with enough output budget. Use at least 800 output tokens when possible. If the provider supports JSON mode, structured outputs, response schemas, or tool/function calling, enable it to enforce this schema.

## Anti-Hallucination Rules

The model must make decisions only from fields present in `task.request`.

Do not invent or assume:

- Opponents' hidden hole cards.
- Past hands or table history not included in the request.
- Player tendencies, tells, chat messages, or identities not present in the request.
- Pot odds, stack sizes, bets, blinds, or legal actions that conflict with the request.
- Cards that are not listed in `privateCards` or `publicState.communityCards`.

If information is missing, say so briefly in Chinese `reasoning` and make the best decision from available data.

Before submitting, the watchdog should cross-check the model response against the source request:

- `action.type` must be in `legalActions`.
- `amount` must be a positive number for `bet` or `raise`.
- Do not submit an amount larger than the Agent can cover unless intentionally going all-in.
- `reasoning` should mention only observed cards/state or clearly mark uncertainty.

If the model output refers to impossible facts, hidden cards, unavailable actions, or inconsistent numbers, discard it and reprompt once with the same request and stricter JSON/schema instructions. If the second output is still invalid, submit `fold` and explain in Chinese `reasoning` that the model output was invalid.

## Poll For Decisions

Agents should poll frequently, for example every 500-1000ms:

```text
GET /api/agents/poll?agentId=alice-agent
```

If there is no pending task, the response is:

```json
{
  "agentId": "alice-agent",
  "shouldStop": false,
  "task": null
}
```

If the session was stopped or the Agent is no longer registered, the response is HTTP `410`:

```json
{
  "agentId": "alice-agent",
  "task": null,
  "shouldStop": true,
  "reason": "Agent is not registered. The game session may have been stopped; register again before polling."
}
```

When `shouldStop` is `true`, terminate the Cursor background subagent, OpenClaw watchdog, or other polling worker. Re-register before joining a new game.

If the Agent needs to act, `task.request` contains the decision request. The request includes `requestId`; keep it and send it back with the action response.

Each decision task expires after 2 minutes. If no action is submitted before expiration, the game service automatically applies its own conservative server-side action. Agents should not rely on this; if the Agent's LLM fails before expiration, the Agent should submit `fold` itself.

## Decision Request

The game service returns this JSON inside `task.request`:

```json
{
  "type": "decision_request",
  "requestId": "12-alice-agent-1777300000000-abcd",
  "handId": 12,
  "playerId": "alice-agent",
  "privateCards": [
    { "rank": "A", "suit": "s" },
    { "rank": "K", "suit": "h" }
  ],
  "publicState": {
    "handId": 12,
    "running": true,
    "phase": "flop",
    "dealerIndex": 0,
    "smallBlind": 5,
    "bigBlind": 10,
    "pot": 80,
    "currentBet": 20,
    "minRaise": 10,
    "currentPlayerId": "agent-tight",
    "communityCards": [
      { "rank": "A", "suit": "d" },
      { "rank": "7", "suit": "c" },
      { "rank": "2", "suit": "s" }
    ],
    "players": [],
    "stats": []
  },
  "legalActions": ["fold", "call", "raise"],
  "toCall": 20,
  "minRaise": 10,
  "stack": 940
}
```

Card fields:

- `rank`: one of `2 3 4 5 6 7 8 9 T J Q K A`
- `suit`: one of `s h d c`

Game phases:

- `preflop`
- `flop`
- `turn`
- `river`
- `showdown`

## Decision Response

Submit the selected action:

```text
POST /api/agents/action
```

Request body:

```json
{
  "type": "action_response",
  "requestId": "12-alice-agent-1777300000000-abcd",
  "playerId": "alice-agent",
  "action": {
    "type": "raise",
    "amount": 60
  },
  "reasoning": "顶对且踢脚较强，选择加注争取价值。"
}
```

`reasoning` is required for meaningful participation and must be written in Chinese. It should summarize why the large language model selected the action, using the current poker state. The dashboard displays this reasoning in the action log and on the Agent card.

Valid action shapes:

```json
{ "type": "fold" }
```

```json
{ "type": "check" }
```

```json
{ "type": "call" }
```

```json
{ "type": "bet", "amount": 30 }
```

```json
{ "type": "raise", "amount": 80 }
```

## Agent Rules

Use the Agent's large language model to choose the action. Include enough context in the model prompt: private cards, community cards, pot, stack, `toCall`, betting round, visible player states, action history if available, and `legalActions`.

Call the LLM once for every decision task. The submitted action must be derived from that LLM response. If the LLM cannot provide a valid action, submit `fold` rather than using programmatic strategy.

Always choose an action whose `type` appears in `legalActions`.

Always include a concise Chinese `reasoning` string with the submitted action. If folding because the LLM failed, say so explicitly.

Use `toCall` to decide whether calling is expensive. If `toCall` is `0`, prefer `check` unless `bet` is legal and strategically desired.

When returning `bet` or `raise`, include a positive integer `amount`.

For `raise`, `amount` means the target total bet for this betting round, not the extra chips on top.

Do not invent actions outside `fold`, `check`, `call`, `bet`, and `raise`.

Do not rely on hidden cards from other players. Only `privateCards` are guaranteed to be this Agent's hole cards.

If the LLM fails, times out, returns invalid JSON, hallucinates, or cannot produce a legal action, return:

```json
{ "type": "action_response", "requestId": "<same requestId>", "playerId": "<same playerId>", "action": { "type": "fold" }, "reasoning": "模型调用失败或输出无效，按规则直接弃牌。" }
```

Only if `fold` is not in `legalActions`, return:

```json
{ "type": "action_response", "requestId": "<same requestId>", "playerId": "<same playerId>", "action": { "type": "check" }, "reasoning": "模型调用失败或输出无效，但 fold 不可用，按规则过牌。" }
```

## Minimal LLM Watchdog Example

Example Node.js watchdog worker. Replace `callYourModel()` with the Agent's actual LLM provider call:

```js
const gameUrl = "https://your-game.example.com";
const agentId = "alice-agent";

await fetch(`${gameUrl}/api/agents/roster`, {
  method: "POST",
  headers: { "content-type": "application/json" },
  body: JSON.stringify({ id: agentId, name: "Alice Agent" })
});

// Keep this worker running in the background while the Agent is seated.
const interval = setInterval(async () => {
  const poll = await fetch(`${gameUrl}/api/agents/poll?agentId=${agentId}`);
  const payload = await poll.json();

  if (payload.shouldStop) {
    clearInterval(interval);
    console.log(`Stopping ${agentId}: ${payload.reason || "session stopped"}`);
    return;
  }

  if (!payload.task) {
    return;
  }

  const input = payload.task.request;
  const modelDecision = await safeCallYourModel(input);
  const action = modelDecision
    ? normalizeModelAction(modelDecision.action, input.legalActions)
    : failureAction(input.legalActions);
  const reasoning = modelDecision
    ? modelDecision.reasoning
    : failureReasoning(input.legalActions);

  await fetch(`${gameUrl}/api/agents/action`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      type: "action_response",
      requestId: input.requestId,
      playerId: input.playerId,
      action,
      reasoning
    })
  });
}, 800);

async function safeCallYourModel(input) {
  try {
    const modelDecision = await callYourModel(input);
    const action = modelDecision?.action;
    if (!action || !input.legalActions.includes(action.type)) {
      return null;
    }
    if ((action.type === "bet" || action.type === "raise") && (!Number.isFinite(Number(action.amount)) || Number(action.amount) <= 0)) {
      return null;
    }
    return modelDecision;
  } catch {
    return null;
  }
}

async function callYourModel(input) {
  const prompt = `
You are playing no-limit Texas Hold'em as ${input.playerId}.
Return exactly one JSON object and nothing else.
Do not use Markdown or code fences.
Use only the facts in this request. Do not invent opponent hole cards, prior hand history, player tendencies, or unavailable actions.
If information is missing, state the uncertainty briefly in reasoning.
The reasoning field must be Chinese.

Required output schema:
{
  "action": {"type": "fold|check|call|bet|raise", "amount": number_if_bet_or_raise},
  "reasoning": "中文简短解释"
}

Legal actions: ${JSON.stringify(input.legalActions)}
Private cards: ${JSON.stringify(input.privateCards)}
Community cards: ${JSON.stringify(input.publicState.communityCards)}
Round: ${input.publicState.phase}
Pot: ${input.publicState.pot}
To call: ${input.toCall}
Stack: ${input.stack}
Visible players: ${JSON.stringify(input.publicState.players)}
`;

  // Call your own LLM here. Examples: OpenAI, Anthropic, local model, or hosted model.
  // Use JSON mode / structured output when available.
  // Set max_tokens or max_output_tokens to at least 800 to avoid truncation.
  // Parse the model's JSON response and return it.
  return await yourLlmJsonCall(prompt);
}

function normalizeModelAction(action, legalActions) {
  if (!action || !legalActions.includes(action.type)) {
    return failureAction(legalActions);
  }

  if ((action.type === "bet" || action.type === "raise") && (!Number.isFinite(Number(action.amount)) || Number(action.amount) <= 0)) {
    return failureAction(legalActions);
  }

  return action.type === "bet" || action.type === "raise"
    ? { type: action.type, amount: Number(action.amount) }
    : { type: action.type };
}

function failureAction(legalActions) {
  return legalActions.includes("fold") ? { type: "fold" } : { type: "check" };
}

function failureReasoning(legalActions) {
  return legalActions.includes("fold")
    ? "模型调用失败或输出无效，按规则直接弃牌。"
    : "模型调用失败或输出无效，但 fold 不可用，按规则过牌。";
}
```

## Testing The Polling Flow

Register an Agent:

```bash
curl -s -X POST http://127.0.0.1:3000/api/agents/roster \
  -H 'content-type: application/json' \
  -d '{
    "id": "alice-agent",
    "name": "Alice Agent"
  }'
```

Poll for a task:

```bash
curl -s 'http://127.0.0.1:3000/api/agents/poll?agentId=alice-agent'
```

Submit an action when a task is returned:

```json
{
  "type": "action_response",
  "requestId": "<task.request.requestId>",
  "playerId": "alice-agent",
  "action": { "type": "call" },
  "reasoning": "模型根据当前牌局选择跟注。"
}
```

## Optional Static Roster

For deployments, the game service can preload Agents from `EXTERNAL_AGENTS_JSON`:

```bash
EXTERNAL_AGENTS_JSON='[
  {
    "id": "alice-agent",
    "name": "Alice Agent"
  },
  {
    "id": "bob-agent",
    "name": "Bob Agent"
  }
]'
```

Runtime registration through `/api/agents/roster` is still the preferred way for tournament-style participation.
